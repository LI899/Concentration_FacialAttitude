from __future__ import division
from imutils.video import VideoStream
from imutils.video import FileVideoStream
import argparse
from imutils import face_utils
import imutils
import dlib
import cv2
import time
import math
import numpy as np
#import matplotlib; matplotlib.use('TkAgg')
import matplotlib
from matplotlib import pyplot
matplotlib.rcParams['backend'] = "Qt4Agg"



import tensorflow as tf 
import align.detect_face 



tu = []
ti = []
count = 0


minsize = 10 # minimum size of face 
threshold = [ 0.8, 0.8, 0.8 ] # three steps's threshold 
factor = 0.709 # scale factor 
gpu_memory_fraction=1.0


with tf.Graph().as_default(): 
    gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=gpu_memory_fraction) 
    sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options, log_device_placement=False)) 
    with sess.as_default(): 
      pnet, rnet, onet = align.detect_face.create_mtcnn(sess, None) 


face_encodings = []
face_names = []
crop_faces = []
process_this_frame = True


shapePredictorPath = 'shape_predictor_68_face_landmarks.dat'
faceDetector = dlib.get_frontal_face_detector()
facialLandmarkPredictor = dlib.shape_predictor(shapePredictorPath)
vs = VideoStream(usePiCamera = False).start()

'''
ap = argparse.ArgumentParser()
ap.add_argument("-p", "--shape-predictor", default="shape_predictor_68_face_landmarks.dat",help="path to facial landmark predictor")
#ap.add_argument("-v", "--video", type=str, default="F:\Videos\PotPlayer1.mp4",help="path to input video file")
#ap.add_argument("-v", "--video", type=str, default="G:\Video_1.mp4",help="path to input video file")
ap.add_argument("-v", "--video", type=str, default="F:\Videos\mins.mp4",help="path to input video file")
args = vars(ap.parse_args())
vs = FileVideoStream(args["video"]).start()
'''

time.sleep(2.0)

def get_image_points_from_landmark_shape(landmark_shape):
    image_points = np.array([
                        (landmark_shape.part(30).x, landmark_shape.part(30).y),
                        (landmark_shape.part(8).x, landmark_shape.part(8).y),
                        (landmark_shape.part(36).x, landmark_shape.part(36).y),
                        (landmark_shape.part(45).x, landmark_shape.part(45).y),
                        (landmark_shape.part(48).x, landmark_shape.part(48).y),
                        (landmark_shape.part(54).x, landmark_shape.part(54).y)
                    ], dtype="double")
    return 0, image_points

         

def get_image_points(img):
    num_faces = bounding_boxes.shape[0]
    if 0 ==  num_faces :
        print( "ERROR: found no face" )
        return -1, None
    face_rectangle = face
    #face_rectangle = bounding_box
    landmark_shape = facialLandmarkPredictor(img, face_rectangle)
    return get_image_points_from_landmark_shape(landmark_shape)
     

def DS_fusion(result,ds):
    lie2 = ds.shape[0]
    lie1 = result.shape[0]
    if lie1 != lie2:
        print('result,ds[i] should equal in column')
        return -1,None
 #   lie1 = result.shape[1]

    temp = 0
    for i in range(0,5):
        result[i]=result[i]*ds[i]+result[i]*ds[4]+ds[i]*result[4]
        if i==4:
            result[i] = result[i]*ds[i]
      #  else:
        #    result[1][i]=result[1][i]*ds[1][i]+result[1][i]*ds[1][lie1-1]+ds[1][i]*result[1][lie1-1]
         #x(1,i)=x(1,i)*y(1,i)+x(1,i)*y(1,mx-1)+y(1,i)*x(1,mx-1);
        temp = temp+result[i]

    for i in range(0,5):
        result[i] = result[i]/temp
    result[5]=0
    return result
     

def get_pose_estimation(img_size, image_points ):

    model_points = np.array([
                                (0.0, 0.0, 0.0),
                                (0.0, -330.0, -65.0),
                                (-225.0, 170.0, -135.0),
                                (225.0, 170.0, -135.0),
                                (-150.0, -150.0, -125.0),
                                (150.0, -150.0, -125.0)
                            ])
     

    focal_length = img_size[1]
    center = (img_size[1]/2, img_size[0]/2)
    camera_matrix = np.array([
                              [focal_length, 0, center[0]],
                              [0, focal_length, center[1]],
                              [0, 0, 1]
                              ], dtype = "double"
                             )   
    
    dist_coeffs = np.zeros((4,1))
    (success, rotation_vector, translation_vector) = cv2.solvePnP(model_points, image_points, camera_matrix, dist_coeffs, flags=cv2.SOLVEPNP_ITERATIVE )
    return success, rotation_vector, translation_vector, camera_matrix, dist_coeffs
    


def get_euler_angle(rotation_vector):
    # calculate rotation angles
    theta = cv2.norm(rotation_vector, cv2.NORM_L2)
    w = math.cos(theta / 2)
    x = math.sin(theta / 2)*rotation_vector[0][0] / theta      
    y = math.sin(theta / 2)*rotation_vector[1][0] / theta
    z = math.sin(theta / 2)*rotation_vector[2][0] / theta
    t0 = 2.0 * (w * x + y * z)
    t1 = 1.0 - 2.0 * (x * x + y * y)
    pitch = math.atan2(t0, t1)
    t2 = 2.0 * (w * y - z * x)
    if t2 > 1.0:
        t2 = 1.0
    if t2 < -1.0:
        t2 = -1.0
    yaw = math.asin(t2)
    t3 = 2.0 * (w * z + x * y)
    t4 = 1.0 - 2.0 * (y * y + z * z)
    roll = math.atan2(t3, t4)
  #  print('pitch:{}, yaw:{}, roll:{}'.format(pitch, yaw, roll))
    Y = int((pitch/math.pi)*180)
    X = int((yaw/math.pi)*180)
    Z = int((roll/math.pi)*180)
    return 0, Y, X, Z                    

'''
if __name__ == '__main__':
    tu = []
    ti = []
    sign = 0
    '''


while True:
    frame = vs.read()
    time_start = time.time()
    #ret, frame2 = video_capture.read()  
    #frame = imutils.resize(frame, width=frame.shape[1]*2,height=frame.shape[0],)
    frame = imutils.resize(frame, width=1000,)
    img = frame[...,::-1]
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    pose = np.zeros((50,3))
    ds = np.zeros((50,6))
    #faces = faceDetector(gray, 0)
    

    if (count % 1 == 0):
        bounding_boxes, _ = align.detect_face.detect_face(img, minsize, pnet, rnet, onet, threshold, factor)
        num_faces = bounding_boxes.shape[0]
        print(num_faces)
        
        for face_position in bounding_boxes: 
            face_position = face_position.astype(int)
            #facialLandmarks = facialLandmarkPredictor(gray, face)
            #facialLandmarks = face_utils.shape_to_np(facialLandmarks)
            
        for (i, face_position) in enumerate(bounding_boxes):         
            #(x, y, w, h) = face_utils.rect_to_bb(face_position)
            x = int(face_position[0])
            y = int(face_position[1])
            face = dlib.rectangle(int(face_position[0]), int(face_position[1]), int(face_position[2]), int(face_position[3]))
            size = frame.shape
            ret, image_points = get_image_points(frame)

            if ret != 0:
                print('get_image_points failed')
                continue
            ret, rotation_vector, translation_vector, camera_matrix, dist_coeffs = get_pose_estimation(size, image_points)

            if ret != True:
                print('get_pose_estimation failed')
                continue

            ret, pitch, yaw, roll = get_euler_angle(rotation_vector)
            if abs(roll)>130:
                if roll>130:
                    roll = -180+roll
                else:
                    roll = 180+roll
            euler_angle = 'Y:{}, X:{}, Z:{}'.format(pitch, yaw, roll)

            '''
            print(euler_angle)
            pose[i] = (pitch,yaw,roll)
            cv2.putText(frame, '#{}:{},{},{}'.format(i+1,pitch,yaw,roll), (x, y-10),cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
            cv2.putText( frame, euler_angle, (0, 120), cv2.FONT_HERSHEY_PLAIN, 1, (0, 0, 255), 1 )
            '''

            #DS
            #ds[i][0] = 2 - abs(pitch)/90
            ds[i][0] = abs(abs(pitch)-170)/180
            ds[i][1] = abs(yaw)/180
            ds[i][2] = abs(roll)/150
            ds[i][3] = 0
            ds[i][4] = 1 - ds[i][0]-ds[i][1]-ds[i][2]
            ds[i][5] = 0


            if (pitch == yaw == roll == 0):
                fen = 0
            else:
                if ds[i][4]<0:
                    fen = abs(1-abs(ds[i][4]))
                    ds[i][4]=fen
                else:
                    fen =ds[i][4]
            fen = fen * 100
            fen = math.floor(fen)

            '''
            nose_end_point2D, ret= cv2.projectPoints(np.array([(0.0, 0.0, 1000.0)]), rotation_vector, translation_vector, camera_matrix, dist_coeffs)

            for p in image_points:
                cv2.circle(frame, (int(p[0]), int(p[1])), 3, (0,0,255), -1)
            p1 = ( int(image_points[0][0]), int(image_points[0][1]))                   
            p2 = ( int(nose_end_point2D[0][0][0]), int(nose_end_point2D[0][0][1]))
            cv2.line(frame, p1, p2, (255,0,0), 2)
            '''
            
    
            #cv2.putText(frame, '#{}: {}'.format(i+1,fen), (x, y-10),cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
           
            if fen >= 75:
                #cv2.rectangle(frame, (x+1, y+1), (x+w+1, y+h+1), (0, 0, 255), 2)
                cv2.putText(frame, '#{}: {}'.format(i+1,fen), (x, y),cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                #print('#{}:{}'.format(i+1,fen))

            else:
                cv2.putText(frame, '#{}: {}'.format(i+1,fen), (x, y),cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
           
            if ds[i][0] > ds[i][1]:
                num = 0
                zuizhi = ds[i][0]
                if zuizhi > 2 - 170/90:
                    cv2.putText(frame, 'Look straight', (x, y-20),cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
            else:
                num = 1
                zuizhi = ds[i][1]
                if zuizhi > 25/180:
                    cv2.putText(frame, 'Look ahead', (x, y-40),cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
    
            if ds[i][2] > zuizhi:
                num = 2
                zuizhi = ds[i][2]
                if zuizhi > 20/150:
                    cv2.putText(frame, 'Sit up', (x, y-60),cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

        time_end = time.time()
        result=ds[0]
        if i > 0:
            for n in range (1,i+1):
                result=DS_fusion(result,ds[n])
                
        atm = result[4]
        atm = atm * 100
        #atm = int(atm)
        atm = math.floor(atm)
      #  print('result={}'.format(result))      
        print('atmosphere:{}'.format(atm))
        tu.append(atm)
        #ti.append(0.1+int(count/24))
        ti.append(0.1 + (time_end - time_start)*count)
        
        if atm ==0:
            number = 0
        else:
            number = i+1
        
        cv2.putText(frame, 'Number {}'.format(number), (800, 40),cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
        
        if atm >= 70:
                cv2.putText(frame, 'atmosphere {}'.format(atm), (0, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255, 0), 2 )
              
        elif 30 < atm <70: 
               
                cv2.putText(frame, 'atmosphere {}'.format(atm), (0, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255, 255), 2 )
                 #print('#{}:{}'.format(i+1,fen))
        elif atm <= 30:
               cv2.putText(frame, 'atmosphere {}'.format(atm), (0, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,0,255), 2 )
    
        if result[0] > result[1]:
            num = 0
            zuizhi = result[0]
            if zuizhi > 2 - 165/180:
                cv2.putText(frame, 'Look straight', (0, 120),cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        else:
            num = 1
            zuizhi = result[1]
            if zuizhi > 25/180:
                cv2.putText(frame, 'Look ahead', (0, 150),cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
    
        if result[2] > zuizhi:
            num = 2
            zuizhi = result[2]
            if zuizhi > 20/150:
                cv2.putText(frame, 'Sit up', (0, 180),cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

        fps = 1 / (time_end - time_start)
        #cv2.putText(frame, "fps:{:.2f}".format(fps),(10, 20), cv2.FONT_HERSHEY_COMPLEX, 0.7, (255, 0, 0))

    count = count+1
    cv2.imshow("Frame", frame)
    key = cv2.waitKey(1) & 0xFF
    if key == ord("q"):
        break

cv2.destroyAllWindows()
vs.stop()

pyplot.plot(ti, tu)
pyplot.xlabel('time/s')
pyplot.ylabel('Concentration degree')
#pyplot.title('')
pyplot.yticks([0, 20, 40, 60, 80, 100])
#pyplot.fill_between(ti, tu, 0, color = 'null')
#pyplot.fill_between(ti, tu, 0, color)
pyplot.show()


